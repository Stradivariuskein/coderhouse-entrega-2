from setuptools import setup

setup(
    name= "paquete_cliente_producto",
    version= "1.0",
    description= "este paquete tiene para calculo matematico",
    author= "Alan",
    author_email= "emaiñ@email.com",
    packagespip = ["paquete1"], # carpetas en formato lista del paquete
)